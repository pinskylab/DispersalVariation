#!/bin/bash
#SBATCH --partition=p_deenr_1
#SBATCH --job-name=2012_test0.026
#SBATCH --nodes=1
#SBATCH --ntasks=28 
#SBATCH --cpus-per-task=1
#SBATCH --mem=112000
#SBATCH --time 48:00:00
#SBATCH --output=slurm.%N.%j.out
#SBATCH --error=slurm.%N.%j.err
#SBATCH --mail-user=kat.catalano@rutgers.edu
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --export=ALL

module purge
module load intel/17.0.4
srun --mpi=pmi2 /home/kac462/colony2.linux_.20180730/colony2p.ifort.impi2015.out IFN:1340loci_2012_0.026.Dat 
