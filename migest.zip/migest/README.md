# migest
Project estimating migration rates from parentage assignment data in a population of clownfish in Leyte, Philippines.
